document.getElementById("formulario").addEventListener("submit", function(event) {
  event.preventDefault();

  let nombre = document.getElementById("nombre").value.trim();
  let email = document.getElementById("email").value.trim();
  let mensaje = document.getElementById("mensaje");

  if (nombre === "" || email === "") {
    mensaje.textContent = "⚠️ Por favor completa todos los campos.";
    mensaje.style.color = "red";
  } else if (!/\S+@\S+\.\S+/.test(email)) {
    mensaje.textContent = "⚠️ Ingresa un correo válido.";
    mensaje.style.color = "red";
  } else {
    mensaje.textContent = "✅ ¡Gracias por suscribirte, " + nombre + "!";
    mensaje.style.color = "green";
    document.getElementById("formulario").reset();
  }
});